import { api, esc } from '../core.js';
import { overviewStatus, attentionItems, strip } from '../status.js';
import { dayLabel, size, ago, duration } from '../format.js';
export async function render(el, { current, state, alive }) {
  const v = current();
  if (!v) {
    el.innerHTML =
      '<h2 class="hero">Add your first vehicle to get started.</h2><a class="btn primary" href="#/settings/vehicles">Add a vehicle</a>';
    return;
  }
  const [d, h, j] = await Promise.all([
    api(`/api/vehicles/${encodeURIComponent(v.id)}/days?limit=40`),
    api('/api/health'),
    api('/api/jobs'),
  ]);
  if (!alive()) return;
  const days = d.days || [],
    checks = h.checks || [],
    status = overviewStatus({ vehicle: v, notes: state.notes, checks, days }),
    items = attentionItems({ vehicle: v, notes: state.notes, checks, days }),
    inv = v.inventory || {},
    s = v.storage,
    cells = strip(days),
    max = Math.max(1, ...cells.map((c) => c.drives + c.other)),
    jobs = (j.jobs || []).filter(
      (j) => j.vehicleId === v.id && ['running', 'waiting', 'paused'].includes(j.status),
    );
  el.innerHTML = `<h2 class="hero ${status.tone === 'bad' ? 'bad' : ''}">${esc(status.first)} <span class="${status.tone === 'warn' ? 'warn' : ''}">${esc(status.second)}</span></h2><p class="hero-sub">${status.sub ? esc(status.sub) + ' · ' : ''}${Number(inv.recordings || 0).toLocaleString()} recordings over ${Number(inv.days || 0).toLocaleString()} days · checked ${ago(inv.scannedAt)}</p>
 <section class="card"><div class="row"><h3 class="grow">What happened lately</h3><a href="#/footage">Open Footage</a></div><div class="day-strip">${cells.map((c) => `<a class="strip-cell ${c.state}" title="${esc(dayLabel(c.day))}" aria-label="${esc(dayLabel(c.day))}: ${c.drives + c.other} recordings" href="#/footage?from=${c.day}&to=${c.day}"><span style="height:${(100 * c.saved) / max}%;background:var(--saved)"></span><span style="height:${(100 * c.sentry) / max}%;background:var(--sentry)"></span><span style="height:${(100 * c.drives) / max}%;background:var(--driving)"></span></a>`).join('')}</div><div class="row muted"><small class="grow">${dayLabel(cells[0].day)}</small><small>Today</small></div><p><span style="color:var(--driving)">●</span> Driving　<span style="color:var(--sentry)">●</span> Sentry　<span style="color:var(--saved)">●</span> Saved　◌ No footage</p><div class="latest-days">${days
   .slice(0, 5)
   .map(
     (d) =>
       `<a class="latest" href="#/viewer?day=${d.day}"><span class="latest-image"><img alt="" src="/api/vehicles/${encodeURIComponent(v.id)}/recordings/${encodeURIComponent(d.thumbId)}/thumbnail"><i>▶</i></span><div><b>${esc(dayLabel(d.day))}</b><p>${Object.entries(
         d.byCategory || {},
       )
         .map(
           ([k, n]) => n + ' ' + (k === 'Recent' ? 'drives' : k === 'Sentry' ? 'Sentry' : 'saved'),
         )
         .join(
           ' · ',
         )} · ${duration(d.minutes)}</p>${d.archive?.state === 'filling' ? '<small>Still arriving</small>' : ''}</div></a>`,
   )
   .join('')}</div></section>
 ${items.length ? `<section><div class="row"><h2 class="grow">Needs your attention</h2><small>${items.length} items</small></div>${items.map((i) => `<article class="card row"><div class="grow"><h3 class="${i.tone}">${esc(i.title)}</h3><p>${esc(i.text)}</p></div><a class="btn" href="${esc(i.action.href)}">${esc(i.action.label)}</a></article>`).join('')}</section>` : ''}
 <div class="grid"><section class="card"><div class="row"><h3 class="grow">Footage</h3><a href="#/footage">Browse</a></div><div class="number">${Number(inv.recordings || 0).toLocaleString()}</div><p>recordings over ${inv.days || 0} days</p><div class="category-bar">${Object.entries(
   inv.byCategory || {},
 )
   .map(([k, c]) => `<span class="category-${esc(k)}" style="flex:${c.recordings}"></span>`)
   .join('')}</div>${Object.entries(inv.byCategory || {})
   .map(
     ([k, c]) =>
       `<div class="row"><span class="grow category-text-${esc(k)}">${k === 'Recent' ? 'Driving' : esc(k)}</span><span class="mono">${c.recordings} · ${size(c.bytes)}</span></div>`,
   )
   .join(
     '',
   )}</section><section class="card"><h3>Space</h3>${s ? `<div class="space-heading"><span class="space-ring" style="--used:${Math.max(0, Math.min(100, 100 * (1 - s.free / s.total)))}%" aria-label="${Math.round((100 * s.free) / s.total)}% free"></span><div><div class="number">${size(s.free)} free</div><p>of ${size(s.total)} on the share</p></div></div><p>Grows about ${size(s.perDay)} a day</p>${s.daysLeft != null ? `<span class="tag">About ${s.daysLeft} days left</span>` : ''}` : '<p>Space information is unavailable.</p>'}</section><section class="card"><div class="row"><h3 class="grow">Activity</h3><a href="#/activity">See all</a></div><div class="number">${jobs.length ? 'Running' : 'Idle'}</div><p>${jobs.length ? `${jobs.length} active jobs` : 'Nothing is running right now'}</p><p>${size(v.saved?.bytes || 0)} saved by converting ${v.saved?.clips || 0} clips</p><a href="#/bin">Recycle Bin: ${size(v.binBytes || 0)}</a><p>Last scan ${ago(inv.scannedAt)}</p></section></div>`;
  el.querySelectorAll('img').forEach(
    (img) =>
      (img.onerror = () => {
        img.hidden = true;
      }),
  );
}
