import { esc, sheet } from '../core.js';
import { dayKey } from '../format.js';
export function open(anchor, { from = '', to = '', daysWithFootage = null, getSummary, onApply }) {
  const el = document.createElement('section'),
    now = new Date();
  let summarySeq = 0;
  let month = new Date(now.getFullYear(), now.getMonth(), 1);
  el.innerHTML = `<h2>Choose days</h2><div class="segments">${['Today', 'Last 7 days', 'Last 30 days', 'This month', 'Custom'].map((x) => `<button data-shortcut="${x}">${x}</button>`).join('')}</div><div class="row"><label>From<input type="date" name="from" value="${esc(from)}"></label><label>To<input type="date" name="to" value="${esc(to)}"></label></div><div class="row"><button data-prev aria-label="Previous month">‹</button><h3 class="grow" data-month></h3><button data-next aria-label="Next month">›</button></div><div class="calendar"></div><p data-summary></p><footer><button data-clear>Clear</button><button class="primary" data-apply>Show these days</button></footer>`;
  el.querySelector('[data-summary]').hidden = !daysWithFootage && !getSummary;
  const close = sheet(el, { anchor, popover: true }),
    a = el.querySelector('[name=from]'),
    b = el.querySelector('[name=to]');
  function draw() {
    el.querySelector('[data-month]').textContent = month.toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });
    const end = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
    el.querySelector('.calendar').innerHTML =
      ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((x) => `<small>${x}</small>`).join('') +
      '<span></span>'.repeat(month.getDay()) +
      Array.from({ length: end }, (_, i) => {
        const key = dayKey(new Date(month.getFullYear(), month.getMonth(), i + 1));
        return `<button data-day="${key}" class="${key >= a.value && key <= b.value ? 'active' : ''}">${i + 1}${daysWithFootage?.has(key) ? '<small>•</small>' : ''}</button>`;
      }).join('');
    const count = [...(daysWithFootage || [])].filter(
      (d) => (!a.value || d >= a.value) && (!b.value || d <= b.value),
    ).length;
    el.querySelector('[data-summary]').textContent = `${count} days with footage`;
    if (getSummary) {
      const ticket = ++summarySeq;
      getSummary({ from: a.value, to: b.value })
        .then((s) => {
          if (ticket === summarySeq && el.isConnected)
            el.querySelector('[data-summary]').textContent =
              `${s.days} days · ${s.recordings} recordings`;
        })
        .catch(() => {});
    }
    el.querySelector('[data-apply]').disabled = !!(a.value && b.value && a.value > b.value);
  }
  el.onclick = (e) => {
    const button = e.target.closest('button');
    if (!button) return;
    if (button.dataset.shortcut) {
      const d = new Date(now);
      switch (button.dataset.shortcut) {
        case 'Today':
          break;
        case 'Last 7 days':
          d.setDate(d.getDate() - 6);
          break;
        case 'Last 30 days':
          d.setDate(d.getDate() - 29);
          break;
        case 'This month':
          d.setDate(1);
          break;
        default:
          a.focus();
          return;
      }
      a.value = dayKey(d);
      b.value = dayKey(now);
      month = new Date(d.getFullYear(), d.getMonth(), 1);
    }
    if (button.hasAttribute('data-prev')) month.setMonth(month.getMonth() - 1);
    if (button.hasAttribute('data-next')) month.setMonth(month.getMonth() + 1);
    if (button.dataset.day) {
      if (!a.value || b.value) {
        a.value = button.dataset.day;
        b.value = '';
      } else if (button.dataset.day < a.value) {
        b.value = a.value;
        a.value = button.dataset.day;
      } else b.value = button.dataset.day;
    }
    if (button.hasAttribute('data-clear')) {
      close();
      onApply({ from: '', to: '' });
      return;
    }
    if (button.hasAttribute('data-apply')) {
      close();
      onApply({ from: a.value, to: b.value });
      return;
    }
    draw();
  };
  a.onchange = b.onchange = draw;
  draw();
}
